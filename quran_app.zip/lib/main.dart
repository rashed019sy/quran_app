
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';

void main() {
  runApp(QuranApp());
}

class QuranApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'القرآن الكريم',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'TraditionalArabic',
      ),
      home: QuranHomePage(),
    );
  }
}

class QuranHomePage extends StatefulWidget {
  @override
  _QuranHomePageState createState() => _QuranHomePageState();
}

class _QuranHomePageState extends State<QuranHomePage> {
  List surahs = [];
  List filteredSurahs = [];

  @override
  void initState() {
    super.initState();
    loadQuranData();
  }

  Future<void> loadQuranData() async {
    String jsonString = await rootBundle.loadString('assets/quran.json');
    List<dynamic> jsonData = json.decode(jsonString);
    setState(() {
      surahs = jsonData;
      filteredSurahs = surahs;
    });
  }

  void filterSurahs(String query) {
    setState(() {
      filteredSurahs = surahs
          .where((surah) => surah['name'].toString().contains(query))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('القرآن الكريم'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(10),
            child: TextField(
              onChanged: filterSurahs,
              decoration: InputDecoration(
                labelText: 'ابحث عن سورة...',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredSurahs.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(filteredSurahs[index]['name']),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            SurahDetailPage(surah: filteredSurahs[index]),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class SurahDetailPage extends StatelessWidget {
  final Map surah;

  SurahDetailPage({required this.surah});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(surah['name']),
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: SingleChildScrollView(
          child: Text(
            surah['text'],
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.right,
          ),
        ),
      ),
    );
  }
}
